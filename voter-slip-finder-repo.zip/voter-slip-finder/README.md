# Voter Slip Finder

श्री श्रीचन्द शर्मा (MLC शिक्षक चुनाव 2026) भाजपा, हापुड़।

A single-file web app for searching voters (Shikshak Nirvachan 2026, Meerut-Saharanpur) and printing or sharing their voter slips (matdata parchi).

## Features
- Search by name, father/husband, institution, address, voter no. or mobile
- Filters: booth, ward, colony, village, institution, gender, relation
- Slip preview with Print, PDF, Image and Share (e.g. WhatsApp)
- Select voters from any booth, then print 9 per A4 page or download one PDF
- Export the selected list as CSV
- Works offline; selection is saved in the browser
- Mobile-friendly layout with a welcome screen

## Use
Open `index.html` in any modern browser. No build step or server needed.

Printing: choose A4, Landscape, Margins "None", and tick "Background graphics".

## Deploy (GitHub Pages)
Settings → Pages → Deploy from a branch → `main` / root.

## Privacy
`index.html` contains voter names, addresses and mobile numbers. Keep this repository **private** unless you are sure the data may be public.
